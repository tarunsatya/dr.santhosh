<footer class="footer footer-static footer-light">
</footer>
</div>
</div>
<!-- ////////////////////////////////////////////////////////////////////////////-->
<!-- BEGIN VENDOR JS-->
<script src="assets/vendors/js/core/jquery-3.3.1.min.js"></script>
<script src="assets/vendors/js/core/popper.min.js"></script>
<script src="assets/vendors/js/core/bootstrap.min.js"></script>
<script src="assets/vendors/js/perfect-scrollbar.jquery.min.js"></script>
<script src="assets/vendors/js/prism.min.js"></script>
<script src="assets/vendors/js/jquery.matchHeight-min.js"></script>
<script src="assets/vendors/js/screenfull.min.js"></script>
<script src="assets/vendors/js/pace/pace.min.js"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<script src="assets/vendors/js/chartist.min.js"></script>
<script src="assets/vendors/js/datatable/datatables.min.js"></script>
<!-- END PAGE VENDOR JS-->
<!-- BEGIN CONVEX JS-->
<script src="assets/js/app-sidebar.js"></script>
<script src="assets/js/notification-sidebar.js"></script>
<script src="assets/js/customizer.js"></script>
<!-- END CONVEX JS-->
<!-- BEGIN PAGE LEVEL JS-->
<script src="assets/js/dashboard-ecommerce.js"></script>
<script src="assets/js/data-tables/datatable-styling.js"></script>
<!-- END PAGE LEVEL JS-->
</body>

</html>