<?php
include "db.php";


// if(isset($_POST['submit_appointment']))
// {
//      $bhead = mysqli_real_escape_string($conn,$_POST['name']);
//      $bhyp_link = mysqli_real_escape_string($conn,$_POST['email']);
//      $balt_text = mysqli_real_escape_string($conn,$_POST['phone']);
//      $balt_text = mysqli_real_escape_string($conn,$_POST['']);
//      $balt_text = mysqli_real_escape_string($conn,$_POST['phone']);

//     $insert=mysqli_query($conn,"INSERT INTO tbl_banners SET banner_title='".$bhead."', banner_img='".$ban_imgurl."',banner_hyperlink='".$bhyp_link."',ban_img_alt_text='".$balt_text."', status=1");
//      if($insert)
//      {
//          echo"<script>alert('Appointment Successfully');</script>";
//          echo "<script> window.location.href='index.php'";
//      }
//      else{
//          echo"<script>alert('Something went wrong please try Again');</script>";
//          echo "<script> window.location.href='index.php'";
//      }
// }     







?>